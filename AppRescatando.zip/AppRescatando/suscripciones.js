// JavaScript específico para la página de suscripciones
document.addEventListener('DOMContentLoaded', function() {
    initializeSuscripcionesPage();
});

function initializeSuscripcionesPage() {
    let selectedPlan = null;
    const plans = {
        basico: {
            name: 'Amigo Peludo',
            price: 10,
            description: 'Plan básico de apoyo mensual'
        },
        estandar: {
            name: 'Guardián Animal',
            price: 25,
            description: 'Plan estándar con beneficios exclusivos'
        },
        premium: {
            name: 'Héroe Rescatista',
            price: 50,
            description: 'Plan premium con máximo impacto'
        }
    };

    // Manejar selección de planes
    const planButtons = document.querySelectorAll('.btn-plan');
    const selectedPlanDiv = document.getElementById('selectedPlan');
    const submitButton = document.getElementById('submitSuscripcion');

    planButtons.forEach(button => {
        button.addEventListener('click', function() {
            const planType = this.getAttribute('data-plan');
            selectedPlan = plans[planType];
            
            // Actualizar UI
            updateSelectedPlanUI(selectedPlan);
            
            // Habilitar botón de envío
            submitButton.disabled = false;
            
            // Scroll suave al formulario
            document.getElementById('formulario-suscripcion').scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    function updateSelectedPlanUI(plan) {
        selectedPlanDiv.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1">${plan.name}</h4>
                    <p class="text-muted mb-0">${plan.description}</p>
                </div>
                <div class="text-end">
                    <div class="plan-price">$${plan.price}/mes</div>
                    <small class="text-muted">Facturación mensual</small>
                </div>
            </div>
        `;
    }

    // Manejo del formulario de suscripción
    const suscripcionForm = document.getElementById('suscripcionForm');
    
    if (suscripcionForm) {
        suscripcionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (!selectedPlan) {
                showAlert('Por favor selecciona un plan antes de continuar.', 'error');
                return;
            }
            
            if (validateSuscripcionForm()) {
                // Simular procesamiento de pago
                processPayment();
            }
        });
    }

    // Validación del formulario
    function validateSuscripcionForm() {
        const requiredFields = suscripcionForm.querySelectorAll('[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.classList.add('is-invalid');
                isValid = false;
            } else {
                field.classList.remove('is-invalid');
            }
        });

        // Validación específica de tarjeta
        const numeroTarjeta = document.getElementById('numeroTarjeta');
        if (numeroTarjeta.value && !isValidCardNumber(numeroTarjeta.value)) {
            numeroTarjeta.classList.add('is-invalid');
            isValid = false;
        }

        const fechaVencimiento = document.getElementById('fechaVencimiento');
        if (fechaVencimiento.value && !isValidExpiryDate(fechaVencimiento.value)) {
            fechaVencimiento.classList.add('is-invalid');
            isValid = false;
        }

        const cvv = document.getElementById('cvv');
        if (cvv.value && !isValidCVV(cvv.value)) {
            cvv.classList.add('is-invalid');
            isValid = false;
        }

        if (!isValid) {
            showAlert('Por favor, completa todos los campos obligatorios correctamente.', 'error');
        }
        
        return isValid;
    }

    // Validaciones de tarjeta
    function isValidCardNumber(cardNumber) {
        const cleaned = cardNumber.replace(/\s/g, '');
        return /^\d{16}$/.test(cleaned);
    }

    function isValidExpiryDate(expiry) {
        return /^\d{2}\/\d{2}$/.test(expiry);
    }

    function isValidCVV(cvv) {
        return /^\d{3,4}$/.test(cvv);
    }

    // Formateadores de entrada
    const numeroTarjetaInput = document.getElementById('numeroTarjeta');
    if (numeroTarjetaInput) {
        numeroTarjetaInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s/g, '').replace(/\D/g, '');
            if (value.length > 16) value = value.substr(0, 16);
            
            // Formatear como XXXX XXXX XXXX XXXX
            let formattedValue = '';
            for (let i = 0; i < value.length; i++) {
                if (i > 0 && i % 4 === 0) formattedValue += ' ';
                formattedValue += value[i];
            }
            
            e.target.value = formattedValue;
        });
    }

    const fechaVencimientoInput = document.getElementById('fechaVencimiento');
    if (fechaVencimientoInput) {
        fechaVencimientoInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 4) value = value.substr(0, 4);
            
            if (value.length >= 2) {
                value = value.substr(0, 2) + '/' + value.substr(2);
            }
            
            e.target.value = value;
        });
    }

    const cvvInput = document.getElementById('cvv');
    if (cvvInput) {
        cvvInput.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '').substr(0, 3);
        });
    }

    // Procesamiento de pago simulado
    function processPayment() {
        const submitBtn = suscripcionForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        
        // Mostrar loading
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Procesando...';
        submitBtn.disabled = true;
        
        // Simular delay de procesamiento
        setTimeout(() => {
            // Simular éxito del pago
            showSuccessModal();
            
            // Restaurar botón
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            
        }, 3000);
    }

    function showSuccessModal() {
        // Crear modal de éxito
        const successModal = document.createElement('div');
        successModal.className = 'modal fade';
        successModal.id = 'successModal';
        successModal.innerHTML = `
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body text-center py-4">
                        <div class="success-icon mb-4">
                            <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                        </div>
                        <h3 class="text-success mb-3">¡Suscripción Exitosa!</h3>
                        <p class="mb-4">Te has convertido en un <strong>${selectedPlan.name}</strong>. 
                        Gracias por unirte a nuestra misión de salvar vidas.</p>
                        <div class="success-details">
                            <p><strong>Plan:</strong> ${selectedPlan.name}</p>
                            <p><strong>Monto:</strong> $${selectedPlan.price} USD/mes</p>
                            <p><strong>Próxima facturación:</strong> ${getNextBillingDate()}</p>
                        </div>
                    </div>
                    <div class="modal-footer border-0 justify-content-center">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">
                            Comenzar Mi Experiencia
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(successModal);
        
        const modal = new bootstrap.Modal(successModal);
        modal.show();
        
        // Limpiar formulario después del éxito
        suscripcionForm.reset();
        selectedPlan = null;
        selectedPlanDiv.innerHTML = '<p class="text-muted">Por favor selecciona un plan arriba</p>';
        submitButton.disabled = true;
        
        // Remover modal del DOM después de cerrar
        successModal.addEventListener('hidden.bs.modal', function() {
            successModal.remove();
        });
    }

    function getNextBillingDate() {
        const today = new Date();
        const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, today.getDate());
        return nextMonth.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }

    function showAlert(message, type) {
        // Usar la función showAlert del script principal si existe
        if (typeof window.showAlert === 'function') {
            window.showAlert(message, type);
        } else {
            // Fallback simple
            alert(message);
        }
    }
}